package com.example.prova_20_09

data class Produto(
    val nome: String,
    val categoria: String,
    val preco: Double,
    val quantidade: Int
)
