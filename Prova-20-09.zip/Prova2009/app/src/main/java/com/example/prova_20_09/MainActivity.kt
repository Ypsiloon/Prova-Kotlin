package com.example.prova_20_09

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.TextField
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.gson.Gson


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LayoutMain()
        }
    }
}

@Composable
fun LayoutMain() {
    val navController = rememberNavController()

    Column(Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        NavHost(navController = navController, startDestination = "cadastroProduto") {
            composable("cadastroProduto") { TelaCadastroProduto(navController) }
            composable("listaProdutos") { TelaListaProdutos(navController) }
            composable("detalhes/{produtoJson}") { backStackEntry ->
                val produtoJson = backStackEntry.arguments?.getString("produtoJson")
                val produto = Gson().fromJson(produtoJson, Produto::class.java)
                TelaDetalhesProduto(navController, produto)
            }
            composable("estatisticas") { TelaEstatisticas(navController) }
        }
    }
}

@Composable
fun TelaCadastroProduto(navController: NavController) {
    var nomeProduto by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf("") }
    var preco by remember { mutableStateOf("") }
    var quantidade by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        Text(text = "Cadastro de Produto", fontSize = 30.sp, fontWeight = FontWeight.Bold)


        TextField(value = nomeProduto, onValueChange = { nomeProduto = it },
            label = { Text("Nome do Produto") })
        Spacer(modifier = Modifier.height(10.dp))

        TextField(value = categoria, onValueChange = { categoria = it },
            label = { Text("Categoria") })
        Spacer(modifier = Modifier.height(10.dp))

        TextField(value = preco, onValueChange = { preco = it },
            label = { Text("Preço") })
        Spacer(modifier = Modifier.height(10.dp))

        TextField(value = quantidade, onValueChange = { quantidade = it },
            label = { Text("Quantidade em Estoque") })
        Spacer(modifier = Modifier.height(10.dp))

        Spacer(modifier = Modifier.height(20.dp))


        Button(onClick = {
            if (nomeProduto.isEmpty() || categoria.isEmpty() || preco.isEmpty() || quantidade.isEmpty()) {
                Toast.makeText(context, "Todos os campos são obrigatórios!", Toast.LENGTH_SHORT).show()
            } else if (preco.toDouble() <= 0 || quantidade.toInt() < 1) {
                Toast.makeText(context, "Preço deve ser maior que 0 e quantidade maior que 0", Toast.LENGTH_SHORT).show()
            } else {
                val novoProduto = Produto(nomeProduto, categoria, preco.toDouble(), quantidade.toInt())
                Estoque.adicionarProduto(novoProduto)
                navController.navigate("listaProdutos")
            }
        }) {
            Text(text = "Cadastrar Produto", fontSize = 18.sp)
        }
    }
}

@Composable
fun TelaListaProdutos(navController: NavHostController) {
    val listaProdutos = Estoque.listarProdutos()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally){

        Text(
            text = "Lista de Produtos",
            fontSize = 28.sp,
            modifier = Modifier.padding(10.dp),
            fontWeight = FontWeight.Bold
        )

        LazyColumn (verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(listaProdutos) { produto ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "${produto.nome} (${produto.quantidade} unidades)")
                    Button(onClick = {
                        val produtoJson = Gson().toJson(produto)
                        navController.navigate("detalhes/$produtoJson")  // Altere aqui para corresponder à rota definida no NavHost
                    }) {
                        Text(text = "Ver Detalhes", fontSize = 14.sp)
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = {
            navController.navigate("estatisticas")
        }) {
            Text(text = "Ver Estatísticas", fontSize = 18.sp)
        }
        Spacer(modifier = Modifier.height(3.dp))

        Button(onClick = {
            navController.navigate("cadastroProduto")
        }) {
            Text(text = "Cadastrar Novo Produto", fontSize = 18.sp)
        }
    }
}

@Composable
fun TelaDetalhesProduto(navController: NavController, produto: Produto) {
    Column(Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        Text(text = "Detalhes do Produto", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(15.dp))

        Text(text = "Nome: ${produto.nome}", fontSize = 20.sp)
        Text(text = "Categoria: ${produto.categoria}", fontSize = 20.sp)
        Text(text = "Preço: R$ ${produto.preco}", fontSize = 20.sp)
        Text(text = "Quantidade em Estoque: ${produto.quantidade}", fontSize = 20.sp)

        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = {
            navController.popBackStack()
        }) {
            Text(text = "Voltar", fontSize = 18.sp)
        }
    }
}

@Composable
fun TelaEstatisticas(navController: NavController) {
    val valorTotal = Estoque.calcularValorTotalEstoque()
    val quantidadeTotal = Estoque.calcularQuantidadeTotalProdutos()

    Column(Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        Text(text = "Estatísticas do Estoque", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(text = "Valor Total do Estoque: R$ $valorTotal", fontSize = 20.sp)
        Text(text = "Quantidade Total de Produtos: $quantidadeTotal unidades", fontSize = 20.sp)

        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = {
            navController.navigate("listaProdutos")
        }) {
            Text(text = "Voltar para Lista de Produtos", fontSize = 18.sp)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewLayout() {
    LayoutMain()
}



